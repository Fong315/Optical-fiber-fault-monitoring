/**
  ******************************************************************************
  * @file      main.c
  * $Author:   ����������ѧ   ����
	* $TEL:      17684323829
  * $Revision: 1.0
  * $Date::    2018.11.10 
  * @brief     ˫·���˹������߼��ϵͳ
	*���⣻  1  OTDR  ��λ��ip��λ  (IP��λ�Ҳ������)  �⿪�� λ��   �������ǵ�һ·��
					2 �⹦��У׼����  
  ******************************************************************************
	                          ���е��豸��IP��ַ���˿ں��Լ�MAC��ַ
	
��·�豸   IP:192.168.1.220  PORT:          OTDR1 IP:192.168.1.248   PORT:      OTDR2 IP:192.168.1.249  PORT:
��һ���豸 IP:192.168.1.221  PORT:5050      MAC: 00 08 dc 00 ab ca	            OTDR IP:192.168.1.181   PORT:5000       ����δ�趨2019.7.29��
�ڶ����豸 IP:192.168.1.222  PORT:5050      MAC: 00 08 dc 00 ab cb	            OTDR IP:192.168.1.182   PORT:5000   
�������豸 IP:192.168.1.223  PORT:5050      MAC: 00 08 dc 00 ab cc	            OTDR IP:192.168.1.183   PORT:5000
�������豸 IP:192.168.1.224  PORT:5050      MAC: 00 08 dc 00 ab cd              OTDR IP:192.168.1.184   PORT:5000
�������豸 IP:192.168.1.225  PORT:5050      MAC: 00 08 dc 00 ab ce	            OTDR IP:192.168.1.185   PORT:5000
�������豸 IP:192.168.1.226  PORT:5050      MAC: 00 08 dc 00 ab cf              OTDR IP:192.168.1.186   PORT:5000
	******************************************************************************	
*                    .::::.                                                                 
 *                  .::::::::.
 *                 :::::::::::  
 *             ..:::::::::::'
 *           '::::::::::::'                       ���ǵ������豸�ĳ���Ŷ������
 *             .::::::::::
 *        '::::::::::::::..                                 ÿһ���豸��IP,MAC��ַ��һ��������
 *             ..::::::::::::.                           
 *           ``::::::::::::::::                                        ��һ�����Ҫ������
 *            ::::``:::::::::'        .:::.
 *           ::::'   ':::::'       .::::::::.                               
 *         .::::'      ::::     .:::::::'::::.
 *        .:::'       :::::  .:::::::::' ':::::.
 *       .::'        :::::.:::::::::'      ':::::.
 *      .::'         ::::::::::::::'         ``::::.
 *  ...:::           ::::::::::::'              ``::.
 * ```` ':.          ':::::::::'                  ::::..
 *                    '.:::::'                    ':'````..
	 
	******************************************************************************
**/
#include "main.h"
#include "usart.h"
#include "delay.h"
#include "spi.h"
#include "socket.h"	
#include "board.h" 
#include "24cxx.h"
#include "adc.h"
#include "iwdg.h"
#include "timer.h"

#define SOCK_TCPS        0    
#define DATA_BUF_SIZE    1500

#define Parameter_size   24
#define swith_time       54

#define SIZEW5500        sizeof(gWIZNETINFO)	
#define SIZEALL          30

#define W5500_ADDRESS		         0x00
#define W5500IP_ADDRESS          0x06      
#define W5500PORTH_ADDRESS	     0x17
#define W5500PORTL_ADDRESS		   0x18
#define MODE_ADDRESS		         0x19
#define WAVE_LEN1_ADDRESS		     0x1A
#define WAVE_LEN2_ADDRESS		     0x1B
#define THRESHOID_ADDRESS	       0x1C

uint16_t    IPPORTH=50;
uint16_t    IPPORTL=50;
uint16_t    IPPORT;
uint16_t    MODE=1;
uint16_t    TIMFLAG=0;
uint16_t    WAVE_LEN1=15;      //A 13_1310   15_1550
uint16_t    WAVE_LEN2=15;      //B 13_1310   15_1550
uint16_t    CRC_value=0;
uint16_t    CRC_receive=0;
uint16_t    THRESHOID=23;

wiz_NetInfo gWIZNETINFO;	

static uint8_t 			 *ptrBuf; 
//static uint8_t 			  FISTWRITE[SIZEALL]; 	
static uint8_t 			  READCACHE[26]; 
extern u16            adc_buf[2];	
float  adc_bufmoni[6];   

uint8_t  TCP_R_Buf[256];                   //TCP Server�������ݻ�����
uint8_t  TCP_T_Buf[256];	                  //TCP������������������
uint8_t  TCP_T_DATA[256]={0};
uint16_t TCP_R_Length=0;
uint16_t TCP_T_Length=0;

void network_init(void);								
void send_pack(uint8_t type,uint8_t mode, uint8_t *buf,uint8_t length);
uint16_t GetCRC(uint8_t *buf, int Lenth);
int main(void)
{ 
	int n,INTH1,INTL1,INTH2,INTL2;
	float K1,K2,C1,C2;
	float K1_1310= -11.82;
  float K1_1550= -11.72;
	float K2_1310= -11.58;
  float K2_1550= -11.50;
	float C1_1310=41.95;
  float C1_1550=43.31;
	float C2_1310=42.15;
  float C2_1550=43.48;	
	uint8_t tmp;
	int32_t ret = 0;
	uint8_t memsize[2][8] = {{2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};
	SystemInit();                  //ϵͳʱ�ӳ�ʼ��
	delay_init(168);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	Adc_Init();
	SPI_Configuration();
	IO_Init();		                
	AT24CXX_Init();		
	TIM3_Int_Init(50000-1,8400-1);	//   x/10ms  
		
#if  0                   
wiz_NetInfo gWIZNETINFO ={0x00, 0x08, 0xdc,0x00, 0xab, 0xce,192, 168, 1, 225,255,255,255,0,192, 168, 1, 1,0,0,0,0,1};
//														wiz_NetInfo gWIZNETINFO = { .mac = {0x00, 0x08, 0xdc,0x00, 0xab, 0xce},
//                            .ip = {192, 168, 0, 123},
//                            .sn = {255,255,255,0},
//                            .gw = {192, 168, 0, 1},
//                            .dns = {0,0,0,0},
//                            .dhcp = NETINFO_STATIC };	
		ptrBuf = &gWIZNETINFO.mac[0]; 
		for(n=0;n<SIZEW5500;n++)
		READCACHE[n]=*ptrBuf++;
		AT24CXX_Write(W5500_ADDRESS,(u8 *)READCACHE,SIZEW5500);
	  delay_ms(10);
	  AT24CXX_WriteOneByte(W5500PORTH_ADDRESS,IPPORTH);
	  delay_ms(10);
	  AT24CXX_WriteOneByte(W5500PORTL_ADDRESS,IPPORTL);
	  delay_ms(10);
	  AT24CXX_WriteOneByte(MODE_ADDRESS,MODE);
	  delay_ms(10);
		AT24CXX_WriteOneByte(WAVE_LEN1_ADDRESS,WAVE_LEN1);
	  delay_ms(10);
		AT24CXX_WriteOneByte(WAVE_LEN2_ADDRESS,WAVE_LEN2);
	  delay_ms(10);
		AT24CXX_WriteOneByte(THRESHOID_ADDRESS,THRESHOID);	

#else							
    AT24CXX_Read(W5500_ADDRESS,(uint8_t *)READCACHE,SIZEALL);      //��ȡEEPROM����  //NumToRead:Ҫ�������ݵĸ���
		ptrBuf = (uint8_t *)READCACHE;
    for(n=0;n<6;n++)
	  gWIZNETINFO .mac[n]=*ptrBuf++;
		for(n=0;n<4;n++)
	  gWIZNETINFO .ip[n]=*ptrBuf++;
	  for(n=0;n<4;n++)
	  gWIZNETINFO .sn[n]=*ptrBuf++;
	  for(n=0;n<4;n++)
	  gWIZNETINFO .gw[n]=*ptrBuf++;
	  for(n=0;n<4;n++)
	  gWIZNETINFO .dns[n]=*ptrBuf++;
	  gWIZNETINFO .dhcp=*ptrBuf++;
	  IPPORTH=*ptrBuf++;
	  IPPORTL=*ptrBuf++;
	  IPPORT=IPPORTH*100+IPPORTL;            //PORT
	  MODE=*ptrBuf++;
		WAVE_LEN1=*ptrBuf++;
		WAVE_LEN2=*ptrBuf++;
    THRESHOID=*ptrBuf++;    	
#endif
      reg_wizchip_cris_cbfunc(SPI_CrisEnter, SPI_CrisExit);	  //ע���ٽ�������
#if   _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_
	reg_wizchip_cs_cbfunc(SPI_CS_Select, SPI_CS_Deselect);      //ע��SPIƬѡ�źź���
#elif _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_FDM_
	reg_wizchip_cs_cbfunc(SPI_CS_Select, SPI_CS_Deselect);      // CS must be tried with LOW.
#else
   #if (_WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_SIP_) != _WIZCHIP_IO_MODE_SIP_
      #error "Unknown _WIZCHIP_IO_MODE_"
   #else
      reg_wizchip_cs_cbfunc(wizchip_select, wizchip_deselect);
   #endif
#endif
	reg_wizchip_spi_cbfunc(SPI_ReadByte, SPI_WriteByte);	      //ע���д����
  if(ctlwizchip(CW_INIT_WIZCHIP,(void*)memsize) == -1){       //WIZCHIP SOCKET Buffer initialize
//		 printf("WIZCHIP Initialized fail.\r\n");
		 while(1);
	}
  do{                                                         /* PHY link status check */
		if(ctlwizchip(CW_GET_PHYLINK, (void*)&tmp) == -1){
//			printf("Unknown PHY Link stauts.\r\n");
			while(1);
		}
	}while(tmp == PHY_LINK_OFF);
	network_init();
	IWDG_Init(4,4000); //���Ƶ��Ϊ64,����ֵΪ500,���ʱ��Ϊ1s	
	GPIO_ResetBits(GPIOF,GPIO_Pin_10);
	delay_ms(500);
	GPIO_SetBits(GPIOF,GPIO_Pin_10);
	while(1)      
	{ 
		switch(getSn_SR(SOCK_TCPS))        	      
		{
			  case SOCK_INIT:	                       
			  listen(SOCK_TCPS);			               
		    break;
				case SOCK_ESTABLISHED:                           
				if(getSn_IR(SOCK_TCPS) & Sn_IR_CON){
          setSn_IR(SOCK_TCPS,Sn_IR_CON);
				  } 					
        ret = recv(SOCK_TCPS,TCP_R_Buf,DATA_BUF_SIZE);	
			  if(ret > 0)              
				{
					CRC_receive=TCP_R_Buf[ret-2];
				  CRC_receive=CRC_receive<<8;
				  CRC_receive+=TCP_R_Buf[ret-1];
				
				  CRC_value=GetCRC(TCP_R_Buf, (ret-4));  
				if((CRC_value==CRC_receive)&&(0xEE==TCP_R_Buf[0])&&(0x55==TCP_R_Buf[1]))      
				 {			   
					  switch(TCP_R_Buf[3])        
		        {
		          case 0x01:	      
			  			switch(TCP_R_Buf[4])
							{
							  case 0x00:
								MODE=1;							
								AT24CXX_WriteOneByte(MODE_ADDRESS,MODE);
								send_pack(0x81,0x00,TCP_T_DATA,3);
							  break;
							  case 0x01:
								MODE=2;
								AT24CXX_WriteOneByte(MODE_ADDRESS,MODE);
				        send_pack(0x81,0x01,TCP_T_DATA,3);	
							  break;
								case 0x10:
								MODE=3;
								AT24CXX_WriteOneByte(MODE_ADDRESS,MODE);
								send_pack(0x81,0x10,TCP_T_DATA,3);
							  break;
							  case 0x11:
								MODE=4;
								AT24CXX_WriteOneByte(MODE_ADDRESS,MODE);
								send_pack(0x81,0x11,TCP_T_DATA,3);
							  break;
							}								
									 
		          break;
		          case 0x02:	    
              switch(TCP_R_Buf[4])
							{
							  case 0x00:     
								switch(TCP_R_Buf[5])	
								{
									case 0x13:
									WAVE_LEN1=13;
									AT24CXX_WriteOneByte(WAVE_LEN1_ADDRESS,WAVE_LEN1);
									TCP_T_DATA[5]=0x13;
									send_pack(0x82,0x00,&TCP_T_DATA[5],4);
									break;
									case 0x15:
									WAVE_LEN1=15;
                  AT24CXX_WriteOneByte(WAVE_LEN1_ADDRESS,WAVE_LEN1);
									TCP_T_DATA[5]=0x15;
									send_pack(0x82,0x00,&TCP_T_DATA[5],4);
									break;
								}
								case 0x01:      
								switch(TCP_R_Buf[5])	
								{
									case 0x13:
									WAVE_LEN2=13;
									AT24CXX_WriteOneByte(WAVE_LEN2_ADDRESS,WAVE_LEN2);
									TCP_T_DATA[5]=0x13;
									send_pack(0x82,0x01,&TCP_T_DATA[5],4);
									break;
									case 0x15:
									WAVE_LEN2=15;	
									AT24CXX_WriteOneByte(WAVE_LEN2_ADDRESS,WAVE_LEN2);
									TCP_T_DATA[5]=0x15;
									send_pack(0x82,0x01,&TCP_T_DATA[5],4);
									break;
								}														
							  break;
		          }
		          break;
		          case 0x03:	            
			 			  switch(TCP_R_Buf[4])
							{
							  case 0x00:
								switch(WAVE_LEN1)	
								{
									case 13:
									TCP_T_DATA[5]=0x13;
									send_pack(0x83,0x00,&TCP_T_DATA[5],4);	
									break;
								  case 15:
									TCP_T_DATA[5]=0x15;
									send_pack(0x83,0x00,&TCP_T_DATA[5],4);	
									break;
								}	
							  break;
							  case 0x01:
								switch(WAVE_LEN2)	
								{
									case 13:
									TCP_T_DATA[5]=0x13;
									send_pack(0x83,0x01,&TCP_T_DATA[5],4);	
									break;
								  case 15:
									TCP_T_DATA[5]=0x15;
									send_pack(0x83,0x01,&TCP_T_DATA[5],4);	
									break;
								}		
							  break;								
		          }     
		          break;
		          case 0x04:	
							THRESHOID=TCP_R_Buf[5];
		          AT24CXX_WriteOneByte(THRESHOID_ADDRESS,THRESHOID);
							TCP_T_DATA[5]=THRESHOID;
              send_pack(0x84,0x00,&TCP_T_DATA[5],4);                     //????								
		          break;
							case 0x05:	                  
			 			  switch(TCP_R_Buf[4])
							{
							  case 0x00:
								adc_bufmoni[4] =adc_bufmoni[2];				       
								INTH1=(int)adc_bufmoni[4];
								TCP_T_DATA[5]=INTH1;
								INTL1=(int)((adc_bufmoni[2]-INTH1)*100);
								TCP_T_DATA[6]=INTL1;
								send_pack(0x87,0x00,&TCP_T_DATA[5],5);
							  break;
							  case 0x01:
								adc_bufmoni[5] =adc_bufmoni[3];
								INTH2=(int)adc_bufmoni[5];
								TCP_T_DATA[5]=INTH2;
								INTL2=(int)((adc_bufmoni[3]-INTH2)*100);
								TCP_T_DATA[6]=INTL2;	
								send_pack(0x87,0x01,&TCP_T_DATA[5],5);
							  break;								
		          }       
		          break;
		          case 0x06:	
              GPIO_ResetBits(GPIOC,GPIO_Pin_3);
							delay_ms(500);
              GPIO_SetBits(GPIOC,GPIO_Pin_3);                
              send_pack(0x85,0x00,TCP_T_DATA,3);                         
		          break;
							case 0x07:	
              switch(MODE)
							{
							  case 1:
								send_pack(0x86,0x00,TCP_T_DATA,3); 	
							  break;
							  case 2:
								send_pack(0x86,0x01,TCP_T_DATA,3);	
							  break;
								case 3:
								send_pack(0x86,0x10,TCP_T_DATA,3);	
							  break;
							  case 4:
								send_pack(0x86,0x11,TCP_T_DATA,3);	
							  break;		
		          }           
		          break;
							case 0x08:	                  
			 			  ptrBuf =&TCP_R_Buf[5];  // (uint8_t *)TCP_R_Buf[5];
							for(n=0;n<4;n++)
		          READCACHE[n]=*ptrBuf++;
		          AT24CXX_Write(0x06,(u8 *)READCACHE,4);
//							for(n=0;n<4;n++)
//	            gWIZNETINFO .ip[n]=*ptrBuf++;
						  IPPORTH=*ptrBuf++;
	            IPPORTL=*ptrBuf++;
							AT24CXX_WriteOneByte(W5500PORTH_ADDRESS,IPPORTH);
							delay_ms(10);
							AT24CXX_WriteOneByte(W5500PORTL_ADDRESS,IPPORTL);
							delay_ms(10);
//							ptrBuf = &TCP_R_Buf[5];; 
		          
							while(1);    //need have dog
		          break;
							case 0x09:	              
			 			  GPIO_SetBits(GPIOC,GPIO_Pin_1); 
              send_pack(0x8b,0x00,TCP_T_DATA,3);
		          break;
							case 0x0a:                 
			 			  GPIO_ResetBits(GPIOC,GPIO_Pin_1);
              send_pack(0x8b,0x01,TCP_T_DATA,3);
		          break;
							case 0x0b:                  //��Ҫ��
			 			  GPIO_ResetBits(GPIOC,GPIO_Pin_3);  
							delay_ms(500);
              GPIO_SetBits(GPIOC,GPIO_Pin_3); 
              send_pack(0x8c,0x00,TCP_T_DATA,3); 
		          break;
			     }
				 }					
			  	else          
				 {
						send_pack(0xFF,0xFF,TCP_T_DATA,3);  //send fuck
				 }	
			  }
				IWDG_Feed();
			  break;				
	      case SOCK_CLOSE_WAIT:	                             //socket�ȴ��ر�״̬
        if((ret=disconnect(SOCK_TCPS)) != SOCK_OK){
        break;
				 }
         break;
        case SOCK_CLOSED:   			                         //socket�ر�
				ret = socket(SOCK_TCPS,Sn_MR_TCP,IPPORT,Sn_MR_ND);   //��socket0��һ���˿�
				if(ret != SOCK_TCPS){
         while(1);
				}
				break;
     }
	   if(13==WAVE_LEN1)
		 {
		   K1=K1_1310 ;
			 C1=C1_1310 ;
		 }
		 else
		 {
		   K1=K1_1550 ;
			 K2=K2_1550 ;
		 }	 
		 if(13==WAVE_LEN2)
		 {
		   K2=K2_1310 ;
			 C2=C2_1310 ;
		 }
		 else
		 {
		   K2=K2_1550 ;
			 K2=K2_1550 ;
		 }	
		 switch(MODE)       
		 {
		    case 1:	
				 if(13==WAVE_LEN1)
				 {
					 K1=K1_1310 ;
					 C1=C1_1310 ;
				 }
				 else
				 {
					 K1=K1_1550 ;
					 C1=C1_1550 ;
				 }	 
				 if(13==WAVE_LEN2)
				 {
					 K2=K2_1310 ;
					 C2=C2_1310 ;
				 }
				 else
				 {
					 K2=K2_1550 ;
					 C2=C2_1550 ;
				 }     
    		adc_bufmoni[0] = (float)adc_buf[0]/4096*(float)3.3;   
		    adc_bufmoni[1] = (float)adc_buf[1]/4096*(float)3.3;
				adc_bufmoni[2] = adc_bufmoni[0]*K1+C1;
				adc_bufmoni[3] = adc_bufmoni[1]*K2+C2;
				if((adc_bufmoni[2]<=THRESHOID)&&(adc_bufmoni[3]<=THRESHOID))  //dd
				{ 			
					TIM_Cmd(TIM3,DISABLE);
          TIMFLAG=0;					
					GPIO_ResetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_SetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_SetBits(GPIOB,GPIO_Pin_5);
					GPIO_ResetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);		
				}
				if((adc_bufmoni[2]>=THRESHOID)&&(adc_bufmoni[3]<=THRESHOID))  //xd
				{ 
					if(0==TIMFLAG)
					{
					  TIM_Cmd(TIM3,ENABLE);
						TIMFLAG=1;
					}
				  GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_ResetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_SetBits(GPIOB,GPIO_Pin_5);
					GPIO_ResetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);	
          		
				}
				if((adc_bufmoni[2]<=THRESHOID)&&(adc_bufmoni[3]>=THRESHOID))  //dx
				{
				  if(0==TIMFLAG)
					{
					  TIM_Cmd(TIM3,ENABLE);
						TIMFLAG=1;
					}
					GPIO_ResetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_SetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_ResetBits(GPIOB,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);	
        	
				}
				if((adc_bufmoni[2]>=THRESHOID)&&(adc_bufmoni[3]>=THRESHOID))   //xx
				{ 
					if(0==TIMFLAG)
					{
					  TIM_Cmd(TIM3,ENABLE);
						TIMFLAG=1;
					}
				  GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_ResetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_ResetBits(GPIOB,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);				
				}
	
		    break;
		    case 2:	           //���� ģʽ
				if(13==WAVE_LEN1)
				 {
					 K1=K1_1310 ;
					 C1=C1_1310 ;
				 }
				 else
				 {
					 K1=K1_1550 ;
					 C1=C1_1550 ;
				 }	 	
    		adc_bufmoni[0] = (float)adc_buf[0]/4096*(float)3.3;
        adc_bufmoni[2] = adc_bufmoni[0]*K1+C1;	
        adc_bufmoni[3] = 0;				 
        if(adc_bufmoni[2]<=THRESHOID)
				{
			    TIM_Cmd(TIM3,DISABLE);
          TIMFLAG=0; 					
					GPIO_ResetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_SetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_SetBits(GPIOB,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_6); 
					GPIO_ResetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);						
				}
				else
				{ 
					if(0==TIMFLAG)
					{
					  TIM_Cmd(TIM3,ENABLE);
						TIMFLAG=1;
					}
					
					GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_ResetBits(GPIOB,GPIO_Pin_1);
					GPIO_SetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_SetBits(GPIOB,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_6); 
					GPIO_ResetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);
				
				}
		    break;
		    case 3:	           //���� ģʽ
				 if(13==WAVE_LEN2)
				 {
					 K2=K2_1310 ;
					 C2=C2_1310 ;
				 }
				 else
				 {
					 K2=K2_1550 ;
					 C2=C2_1550 ;
				 } 					
		    adc_bufmoni[1] = (float)adc_buf[1]/4096*(float)3.3;
        adc_bufmoni[3] = adc_bufmoni[1]*K2+C2;
        adc_bufmoni[2] = 0;				 
				if(adc_bufmoni[3]<=THRESHOID)
				{ 
					TIM_Cmd(TIM3,DISABLE); 
					TIMFLAG=0; 
					GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_SetBits(GPIOB,GPIO_Pin_1);
					GPIO_ResetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_SetBits(GPIOB,GPIO_Pin_5);
					GPIO_ResetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);						
				}
				else
				{ 
					if(0==TIMFLAG)
					{
					  TIM_Cmd(TIM3,ENABLE);
						TIMFLAG=1;
					}
					GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
          GPIO_SetBits(GPIOB,GPIO_Pin_1);
					GPIO_ResetBits(GPIOB,GPIO_Pin_3); 
					GPIO_SetBits(GPIOB,GPIO_Pin_4);	
					GPIO_ResetBits(GPIOB,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_6); 
					GPIO_SetBits(GPIOB,GPIO_Pin_14);	
					GPIO_SetBits(GPIOB,GPIO_Pin_15);						
				}			 					
		    break;
		    case 4:	           //���� ģʽ 
				adc_bufmoni[2] = 0;	
				adc_bufmoni[3] = 0;	
        TIM_Cmd(TIM3,DISABLE); 
        TIMFLAG=0; 				
		    GPIO_SetBits(GPIOB,GPIO_Pin_0); 		
        GPIO_SetBits(GPIOB,GPIO_Pin_1);
        GPIO_ResetBits(GPIOB,GPIO_Pin_3); 
        GPIO_SetBits(GPIOB,GPIO_Pin_4);	
        GPIO_SetBits(GPIOB,GPIO_Pin_5);
        GPIO_SetBits(GPIOB,GPIO_Pin_6); 
        GPIO_ResetBits(GPIOB,GPIO_Pin_14);	
        GPIO_SetBits(GPIOB,GPIO_Pin_15);  												        
		    break;
	  }
//	IWDG_Feed();
	}   
}
/***********************************************************/
void network_init(void)
{
  uint8_t tmpstr[6];
	ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
	ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);
	ctlwizchip(CW_GET_ID,(void*)tmpstr);
}
/***********************************************************/
void send_pack(uint8_t type,uint8_t mode, uint8_t *buf,uint8_t length)
{
	uint8_t ci=0,cj=0;    //,value=0xaa
	uint16_t crcsum=0;

	TCP_T_Buf[cj++]=0xee;
	TCP_T_Buf[cj++]=0x55;

	TCP_T_Buf[cj++]=length;	
	TCP_T_Buf[cj++]=type;		
	TCP_T_Buf[cj++]=mode;		
		
	for(ci=0;ci<(length-3);ci++)
	TCP_T_Buf[cj++]=*buf++;
	
	crcsum=0;
	for(ci=0;ci<TCP_T_Buf[2];ci++)
	{
		crcsum+=TCP_T_Buf[ci+2];
	}	
	TCP_T_Buf[cj++]=(uint8_t)(crcsum>>8);	//��λ
	TCP_T_Buf[cj++]=(uint8_t)crcsum;	    //��λ	
	TCP_T_Length=cj;
//		TCPdata_T_valid=0;						//0��Ч 1��Ч
  send(SOCK_TCPS,TCP_T_Buf,TCP_T_Length );	
}
/***********************************************************/
uint16_t GetCRC(uint8_t *buf, int Lenth)
{
uint16_t value = 0, i;

    for (i = 0; i < Lenth; i++)
    {
      value +=buf[i+2];
    }
   return value;
}
/***********************************************************/
void TIM3_IRQHandler(void)
{	
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET) //����ж�
	{  
     switch(MODE)       
		 {
		    case 1:	          			
				if((adc_bufmoni[2]>THRESHOID)&&(adc_bufmoni[3]<=THRESHOID))  //xd
				{				  	
          send_pack(0x88,0x00,TCP_T_DATA,3);					
				}
				if((adc_bufmoni[2]<=THRESHOID)&&(adc_bufmoni[3]>THRESHOID))  //dx
				{				  	
          send_pack(0x89,0x00,TCP_T_DATA,3);					
				}
				if((adc_bufmoni[2]>THRESHOID)&&(adc_bufmoni[3]>THRESHOID))   //xx
				{				  
          send_pack(0x8a,0x00,TCP_T_DATA,3);						
				}	
		    break;
		    case 2:	           //���� ģʽ             
        if(adc_bufmoni[2]>THRESHOID)				
          send_pack(0x88,0x00,TCP_T_DATA,3); 					
		    break;
		    case 3:	           //���� ģʽ                  
				if(adc_bufmoni[3]>THRESHOID)
          send_pack(0x89,0x00,TCP_T_DATA,3);						 					
		    break;
//		    case 4:	           //���� ģʽ    
//		    										        
//		    break;
	  }	
	}
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  //����жϱ�־λ
}

