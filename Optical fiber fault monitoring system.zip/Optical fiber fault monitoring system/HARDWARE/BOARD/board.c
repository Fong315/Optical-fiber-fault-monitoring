#include "board.h" 
#include "sys.h"


void IO_Init(void)
{    	 
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB |RCC_AHB1Periph_GPIOC  |RCC_AHB1Periph_GPIOF, ENABLE);//ʹ��GPIOFʱ��


  GPIO_InitStructure.GPIO_Pin =GPIO_Pin_10;//LED��ӦIO��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOF, &GPIO_InitStructure);//��ʼ��GPIO
	
	GPIO_InitStructure.GPIO_Pin =(GPIO_Pin_0| GPIO_Pin_1| GPIO_Pin_3| GPIO_Pin_4| GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_14| GPIO_Pin_15);
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIO
	
	GPIO_InitStructure.GPIO_Pin =(GPIO_Pin_1| GPIO_Pin_2| GPIO_Pin_3);
	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIO

	GPIO_SetBits(GPIOB,GPIO_Pin_0| GPIO_Pin_1| GPIO_Pin_3| GPIO_Pin_4| GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_14| GPIO_Pin_15);   //MODE LED ���øߣ�����
	GPIO_SetBits(GPIOF,GPIO_Pin_10);   //F10���øߣ�����
	GPIO_SetBits(GPIOC, GPIO_Pin_2| GPIO_Pin_3);   //C1 SWITCH   C2 OTDR IP RESET  C3 OTDR RESET
  GPIO_ResetBits(GPIOC,GPIO_Pin_1);   //C1 SWITCH   C2 OTDR IP RESET  C3 OTDR RESET
}


