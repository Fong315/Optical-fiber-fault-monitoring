#ifndef __BOARD_H
#define __BOARD_H
#include "sys.h"




//LED�˿ڶ���
#define LED0 PFout(9)	// DS0
#define LED1 PFout(10)	// DS1	 

void IO_Init(void);//��ʼ��		 				    
#endif

